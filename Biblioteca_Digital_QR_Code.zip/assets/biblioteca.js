(() => {
  'use strict';
  const categories = [
    {id:'todos', name:'Todos',icon:'✦'}, {id:'video',name:'Vídeos',icon:'🎬'},
    {id:'audio',name:'Músicas e áudios',icon:'🎵'}, {id:'imagem',name:'Imagens',icon:'📷'},
    {id:'documento',name:'Documentos',icon:'📄'}, {id:'outros',name:'Outros',icon:'💾'}
  ];
  const byId = id => document.getElementById(id);
  const clean = str => String(str || '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  const icons = Object.fromEntries(categories.map(c=>[c.id,c.icon]));
  const labels = Object.fromEntries(categories.map(c=>[c.id,c.name]));
  let raw = window.BIBLIOTECA_DADOS || {nome:'Biblioteca Digital',descricao:'',itens:[]};
  if (new URLSearchParams(location.search).get('preview') === '1') {
    try { const local = JSON.parse(localStorage.getItem('biblioteca-rascunho') || 'null'); if(local && Array.isArray(local.itens)) raw = local; } catch {}
  }
  const data = {...raw, itens:Array.isArray(raw.itens) ? raw.itens.filter(x=>x && x.titulo && x.link && categories.some(c=>c.id===x.tipo && c.id!=='todos')) : []};
  let active='todos', lastFocus=null;
  function safeUrl(input) {
    if(typeof input !== 'string') return null;
    const text=input.trim();
    if(!text || text.startsWith('//') || text.startsWith('\\\\')) return null;
    try { const url=new URL(text, location.href);
      if(url.protocol==='http:' || url.protocol==='https:') return url.href;
      if(url.protocol==='file:' && !/^[a-z][a-z\d+.-]*:/i.test(text) && !text.startsWith('/')) return url.href;
    }catch{} return null;
  }
  function filenameType(url) {try{return new URL(url).pathname.toLowerCase();}catch{return '';}}
  function driveId(link){
    try {const u=new URL(link);if(u.hostname!=='drive.google.com')return null;
      const match=u.pathname.match(/\/file\/d\/([\w-]+)/);return match?.[1] || u.searchParams.get('id');
    }catch{return null;}
  }
  function youtubeId(link) {
    try {const u=new URL(link);let id=null;
      if(['youtube.com','www.youtube.com','m.youtube.com'].includes(u.hostname)) id=u.searchParams.get('v') || u.pathname.match(/^\/(?:shorts|live|embed)\/([\w-]{11})/)?.[1];
      if(u.hostname==='youtu.be'||u.hostname==='www.youtu.be') id=u.pathname.slice(1).split('/')[0];
      return /^[\w-]{11}$/.test(id || '') ? id : null;
    } catch{return null;}
  }
  function renderCategories() {
    const el=byId('filters');el.replaceChildren();
    for(const cat of categories){const count=cat.id==='todos'?data.itens.length:data.itens.filter(x=>x.tipo===cat.id).length;
      const btn=document.createElement('button');btn.type='button';btn.className='filter';btn.setAttribute('aria-pressed',String(cat.id===active));
      const icon=document.createElement('span');icon.textContent=cat.icon; icon.setAttribute('aria-hidden','true');
      const label=document.createElement('span');label.textContent=cat.name;
      const counter=document.createElement('small');counter.textContent=String(count);
      btn.append(icon,label,counter);btn.addEventListener('click',()=>{active=cat.id;renderCategories();renderCards();});el.append(btn);
    }
  }
  function renderCards(){
    const q=clean(byId('busca').value.trim());const items=data.itens.filter(x=>(active==='todos'||x.tipo===active)&&clean([x.titulo,x.descricao,x.tipo].join(' ')).includes(q));
    byId('resultCount').textContent=items.length===1?'1 resultado':`${items.length} resultados`;
    const grid=byId('mediaGrid');grid.replaceChildren();
    if(!items.length){const empty=document.createElement('div');empty.className='empty';
      const emoji=document.createElement('div');emoji.className='big';emoji.textContent=q?'🔎':'📚';
      const title=document.createElement('h3');title.textContent=q?'Nenhum resultado encontrado':'Nenhum material nesta categoria';
      const message=document.createElement('p');message.textContent=q?'Experimente outro termo ou categoria.':'Quando novos arquivos forem cadastrados, eles aparecerão aqui.';
      empty.append(emoji,title,message);grid.append(empty);return;}
    for(const item of items){
      const card=document.createElement('article');card.className='media-card';
      const art=document.createElement('div');art.className=`card-visual ${item.tipo}`;
      const icon=document.createElement('span');icon.className='card-emoji';icon.textContent=icons[item.tipo]||'📦';icon.setAttribute('aria-hidden','true');art.append(icon);
      if(item.exemplo){const flag=document.createElement('span');flag.className='sampleflag';flag.textContent='Exemplo';art.append(flag);}
      const body=document.createElement('div');body.className='card-body';
      const kind=document.createElement('span');kind.className='card-kind';kind.textContent=labels[item.tipo]||'Arquivo';
      const title=document.createElement('h3');title.textContent=item.titulo;
      const desc=document.createElement('p');desc.textContent=item.descricao||'Material disponível para consulta.';
      body.append(kind,title,desc);
      const footer=document.createElement('div');footer.className='card-action';
      const btn=document.createElement('button');btn.type='button';btn.textContent=item.tipo==='audio'?'Ouvir / abrir →':item.tipo==='video'?'Assistir / abrir →':'Visualizar / abrir →';btn.addEventListener('click',()=>openModal(item));
      const hint=document.createElement('span');hint.textContent=item.exemplo?'Demonstração':'Acesso online';footer.append(btn,hint);
      card.append(art,body,footer);grid.append(card);
    }
  }
  function openModal(item){
    const link=safeUrl(item.link);if(!link){alert('O endereço deste arquivo não é válido.');return;}
    lastFocus=document.activeElement;byId('modalTitle').textContent=item.titulo;byId('modalDesc').textContent=item.descricao||'Material da biblioteca';
    byId('originalLink').href=link;
    const viewer=byId('viewer');viewer.replaceChildren();const path=filenameType(link),drive=driveId(link),youtube=youtubeId(link);
    let view;
    if(youtube && item.tipo==='video'){
      view=document.createElement('iframe');view.src=`https://www.youtube-nocookie.com/embed/${youtube}`;view.title=item.titulo;view.allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';view.allowFullscreen=true;
    }else if(drive){
      view=document.createElement('iframe');view.src=`https://drive.google.com/file/d/${drive}/preview`;view.title=item.titulo;view.allow='autoplay';view.allowFullscreen=true;
    }else if(item.tipo==='video' && /\.(mp4|webm|ogv|ogg)$/.test(path)){
      view=document.createElement('video');view.src=link;view.controls=true;view.preload='metadata';view.playsInline=true;
    }else if(item.tipo==='audio' && /\.(mp3|wav|m4a|aac|oga|ogg|flac)$/.test(path)){
      view=document.createElement('audio');view.src=link;view.controls=true;view.preload='metadata';
    }else if(item.tipo==='imagem' && /\.(jpe?g|png|gif|svg|webp|avif)$/.test(path)){
      view=document.createElement('img');view.src=link;view.alt=item.titulo;
    }else if(item.tipo==='documento' && /\.pdf$/.test(path)){
      view=document.createElement('iframe');view.src=link;view.title=item.titulo;
    }else{
      view=document.createElement('p');view.className='info';view.textContent='Este formato não possui visualização integrada. Use o botão abaixo para abrir o arquivo original em outra aba.';
    }
    viewer.append(view);byId('overlay').hidden=false;document.body.style.overflow='hidden';byId('modalClose').focus();
  }
  function closeModal(){byId('overlay').hidden=true;byId('viewer').replaceChildren();document.body.style.overflow='';lastFocus?.focus();}
  byId('modalClose').addEventListener('click',closeModal);
  byId('overlay').addEventListener('click',e=>{if(e.target===byId('overlay'))closeModal();});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!byId('overlay').hidden)closeModal();if(e.key==='/' && byId('overlay').hidden && !/input|textarea/i.test(document.activeElement.tagName)){e.preventDefault();byId('busca').focus();}});
  byId('busca').addEventListener('input',renderCards);
  const name=String(data.nome||'Biblioteca Digital');
  byId('brandName').textContent=name;byId('footerName').textContent=name;
  byId('heroDesc').textContent=String(data.descricao||'Descubra vídeos, músicas, imagens e documentos em um único lugar. Escolha uma categoria ou pesquise o que deseja encontrar.');
  document.title=`${name} | Acervo online`;
  byId('totalItems').textContent=String(data.itens.length);
  byId('totalCats').textContent=String(new Set(data.itens.map(x=>x.tipo)).size);
  byId('demoAlert').hidden=!data.itens.some(x=>x.exemplo);
  byId('year').textContent=new Date().getFullYear();
  renderCategories();renderCards();
})();
