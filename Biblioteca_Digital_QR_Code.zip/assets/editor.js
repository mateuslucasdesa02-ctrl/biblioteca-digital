(() => {
  'use strict';
  const $=id=>document.getElementById(id);
  const original=JSON.parse(JSON.stringify(window.BIBLIOTECA_DADOS || {nome:'Biblioteca Digital',descricao:'',itens:[]}));
  let data;
  try { const draft=JSON.parse(localStorage.getItem('biblioteca-rascunho')||'null');data=draft&&Array.isArray(draft.itens)?draft:original; }
  catch {data=original;}
  let editIndex=-1;
  const icon={video:'🎬',audio:'🎵',imagem:'📷',documento:'📄',outros:'💾'};
  const label={video:'Vídeo',audio:'Áudio',imagem:'Imagem',documento:'Documento',outros:'Outro'};
  function persist(){localStorage.setItem('biblioteca-rascunho',JSON.stringify(data));$('draftStatus').textContent='Rascunho salvo neste navegador · ainda não publicado';renderList();}
  function resetForm(){editIndex=-1;$('itemForm').reset();$('saveItem').textContent='+ Adicionar material';$('cancelEdit').hidden=true;$('itemError').hidden=true;}
  function validLink(link){if(!link)return false;try{const u=new URL(link,location.href);if(['https:','http:'].includes(u.protocol) && !/^\/\//.test(link))return true;if(!/^[a-z][\w+.-]*:/i.test(link)&&!link.startsWith('/')&&!link.startsWith('\\')&&!link.includes('..'))return true;}catch{}return false;}
  function renderList(){const list=$('list');list.replaceChildren();$('total').textContent=String(data.itens.length);
    if(!data.itens.length){const m=document.createElement('p');m.className='helptext';m.textContent='Nenhum material cadastrado. Use o formulário ao lado para começar.';list.append(m);return;}
    data.itens.forEach((item,index)=>{
      const row=document.createElement('div');row.className='edit-item';
      const symbol=document.createElement('div');symbol.className='edit-icon';symbol.textContent=icon[item.tipo]||'💾';
      const meta=document.createElement('div');meta.className='edit-meta';const title=document.createElement('b');title.textContent=item.titulo;const type=document.createElement('span');type.textContent=(label[item.tipo]||'Arquivo')+(item.exemplo?' · exemplo':'');meta.append(title,type);
      const edit=document.createElement('button');edit.textContent='Editar';edit.title='Editar este item';edit.addEventListener('click',()=>{
        editIndex=index;$('tipo').value=item.tipo;$('titulo').value=item.titulo;$('resumo').value=item.descricao||'';$('link').value=item.link;
        $('saveItem').textContent='Salvar alterações';$('cancelEdit').hidden=false;$('itemError').hidden=true;$('titulo').focus();scrollTo({top:100,behavior:'smooth'});
      });
      const remove=document.createElement('button');remove.textContent='Excluir';remove.title='Remover este item';remove.addEventListener('click',()=>{if(!confirm(`Remover "${item.titulo}" do rascunho?`))return;data.itens.splice(index,1);resetForm();persist();});
      row.append(symbol,meta,edit,remove);list.append(row);
    });
  }
  $('nome').value=data.nome||'';$('descricao').value=data.descricao||'';
  for(const id of ['nome','descricao'])$(id).addEventListener('input',()=>{data[id==='nome'?'nome':'descricao']=$(id).value.trim();persist();});
  $('itemForm').addEventListener('submit',e=>{e.preventDefault();
    const tipo=$('tipo').value,titulo=$('titulo').value.trim(),descricao=$('resumo').value.trim(),link=$('link').value.trim();
    if(!titulo||!validLink(link)){$('itemError').textContent='Informe um título e um link válido (https://... ou um arquivo relativo do projeto).';$('itemError').hidden=false;return;}
    const old=editIndex>=0?data.itens[editIndex]:null;
    const obj={id:old?.id||`arquivo-${Date.now()}-${data.itens.length}`,tipo,titulo,descricao,link};
    if(editIndex>=0) data.itens[editIndex]=obj;else data.itens.unshift(obj);
    resetForm();persist();
  });
  $('cancelEdit').addEventListener('click',resetForm);
  $('preview').addEventListener('click',()=>{persist();window.open('index.html?preview=1','_blank','noopener');});
  $('download').addEventListener('click',()=>{
    data.nome=($('nome').value.trim()||'Biblioteca Digital');data.descricao=$('descricao').value.trim();
    const content='// Arquivo gerado pelo Editor da Biblioteca Digital\nwindow.BIBLIOTECA_DADOS = '+JSON.stringify(data,null,2)+';\n';
    const blob=new Blob([content],{type:'text/javascript;charset=utf-8'});const url=URL.createObjectURL(blob);
    const a=document.createElement('a');a.href=url;a.download='conteudo.js';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),500);
    $('draftStatus').textContent='Arquivo baixado. Agora publique-o no GitHub.';
  });
  $('clearSamples').addEventListener('click',()=>{const count=data.itens.filter(x=>x.exemplo).length;
    if(!count){alert('Não há mais exemplos para remover.');return;}
    if(!confirm(`Remover ${count} arquivo(s) de demonstração do seu rascunho?`))return;
    data.itens=data.itens.filter(x=>!x.exemplo);resetForm();persist();
  });
  $('reset').addEventListener('click',()=>{if(!confirm('Descartar o rascunho e restaurar o conteúdo do arquivo atual?'))return;
    localStorage.removeItem('biblioteca-rascunho');data=JSON.parse(JSON.stringify(original));$('nome').value=data.nome;$('descricao').value=data.descricao;resetForm();renderList();$('draftStatus').textContent='Editor local: restaurado do arquivo original';
  });
  renderList();
})();
