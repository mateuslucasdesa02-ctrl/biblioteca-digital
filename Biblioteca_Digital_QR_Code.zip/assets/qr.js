(()=>{
'use strict';
const input=document.getElementById('siteUrl'),out=document.getElementById('qrRender'),err=document.getElementById('qrError'),download=document.getElementById('downloadQr');
if(['https:','http:'].includes(location.protocol) && !['localhost','127.0.0.1','0.0.0.0'].includes(location.hostname)){
  const site=new URL('./',location.href);input.value=site.href;
}
let generated=false;
function make(){err.textContent='';generated=false;download.disabled=true;
  let url;try{url=new URL(input.value.trim());if(!['https:','http:'].includes(url.protocol) || ['localhost','127.0.0.1','0.0.0.0'].includes(url.hostname))throw Error('');}
  catch{err.textContent='Informe um endereço válido começando por https://';return;}
  if(typeof QRCode==='undefined'){err.textContent='Não foi possível carregar o gerador. Verifique sua conexão com a internet e atualize esta página.';return;}
  out.replaceChildren();new QRCode(out,{text:url.href,width:256,height:256,colorDark:'#0c2842',colorLight:'#ffffff',correctLevel:QRCode.CorrectLevel.H});
  document.getElementById('qrCaption').textContent=url.href;generated=true;download.disabled=false;
}
document.getElementById('createQr').addEventListener('click',make);
download.addEventListener('click',()=>{
 if(!generated)return;
 const canvas=out.querySelector('canvas');const image=out.querySelector('img');
 const src=canvas?.toDataURL('image/png')||image?.src;
 if(!src){err.textContent='Ainda não há imagem para baixar. Gere novamente o QR Code.';return;}
 const a=document.createElement('a');a.download='qr-code-biblioteca.png';a.href=src;document.body.append(a);a.click();a.remove();
});
})();
