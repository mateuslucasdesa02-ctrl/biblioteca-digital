// Este arquivo guarda o conteúdo público da biblioteca.
// Para editá-lo sem programação, abra editor.html e clique em "Baixar conteudo.js".
window.BIBLIOTECA_DADOS = {
  "nome": "Biblioteca Digital",
  "descricao": "Vídeos, músicas, imagens e documentos em um único lugar, disponíveis pela internet. Explore o acervo e encontre o que precisa.",
  "itens": [
    {"id":"exemplo-video","tipo":"video","titulo":"Vídeo de demonstração","descricao":"Pequeno vídeo original de teste para verificar a reprodução no navegador.","link":"assets/video-demonstracao.mp4","exemplo":true},
    {"id":"exemplo-audio","tipo":"audio","titulo":"Áudio de demonstração","descricao":"Uma breve vinheta de teste para experimentar o reprodutor de áudio.","link":"assets/audio-demonstracao.wav","exemplo":true},
    {"id":"exemplo-imagem","tipo":"imagem","titulo":"Imagem de demonstração","descricao":"Exemplo de imagem que pode ser visualizada sem sair da biblioteca.","link":"assets/imagem-demonstracao.svg","exemplo":true},
    {"id":"exemplo-documento","tipo":"documento","titulo":"Instruções de demonstração","descricao":"Um arquivo de texto com orientações para cadastrar materiais próprios.","link":"assets/leia-me.txt","exemplo":true}
  ]
};
